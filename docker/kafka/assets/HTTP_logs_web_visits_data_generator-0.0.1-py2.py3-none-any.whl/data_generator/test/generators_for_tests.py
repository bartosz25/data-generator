def generate_pages_map():
    return {
        'page1': ['page2', 'page3', 'page4'],
        'page2': ['page1', 'page2-1'],
        'page3': ['page1'],
        'page4': ['page1']
    }
